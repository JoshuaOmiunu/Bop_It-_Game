const highScoreNode = document.getElementById("highScr");
const currentScoreNode = document.getElementById("currentScr");
const controlButton = document.getElementById("controlButn");
const gameStateIndicator = document.getElementById("indication");
const allSimonFlashSignalButtons =document.querySelectorAll(".button-press");

let recordHighScore = 0;
let currentScore = 0;
let sequenceIndex = 0;
let globalExpiryCountdown;

let simonSignalInterval = 1000; // 1000 ms = 1s;

let isGamePlaying = false;
let isSimonPlaying = false;

let simonGenerateRandomArray = [];

controlButton.addEventListener("click", handleGameSequence);

function handleGameSequence() {
  if (!isGamePlaying) {
    startGame();
  }
}

function startExpiryCountdown() {
  clearTimeout(globalExpiryCountdown);

  globalExpiryCountdown = setTimeout(() => {
    signalToUserThatGameHasBeenLost();
    resetGame();
  }, 5000);
}

// Function to stop the timer
function stopExpiryCountdown() {
  clearTimeout(globalExpiryCountdown);
}

function startGame() {
  isGamePlaying = true;
  currentScoreNode.innerText = formatScoreToMin2Digits(currentScore);
  // Turn the indicator to green
  gameStateIndicator.classList.add("game-on");

  // Start game after 3 seconds
  setTimeout(generateSimonFlashLightsSequence, 3000);
}

function generateSimonFlashLightsSequence() {
 
  stopExpiryCountdown();
  isSimonPlaying = true;
  let randomIndex = Math.floor(Math.random() * 4);
 
  simonGenerateRandomArray.push(randomIndex);

 
  if (simonGenerateRandomArray.length > 0) {
    if (simonGenerateRandomArray.length <= 5) {
      simonSignalInterval = 1000;
    } else if (
      simonGenerateRandomArray.length > 5 &&
      simonGenerateRandomArray.length <= 9
    ) {
      simonSignalInterval = 750;
    } else {
      simonSignalInterval = 500;
    }
  }

  // Make simon flash Lights
  flashSimonLights();
}

// Function to handle automatic flashing of Simon Light
function flashSimonLights() {
  // Define the index of the button to be flashed
  let buttonIndex = 0;

  // Define the interval ID
  let intervalID = null;

  // Function to flash simon button
  function flashSimonButtonLight() {
    // Get the index of the button to be flashed from the numbers array
    if (simonGenerateRandomArray.length > 0) {
      let buttonNumber = simonGenerateRandomArray[buttonIndex];

      // Add the active class to the button with the corresponding number
      allSimonFlashSignalButtons[buttonNumber].classList.add("active");

      // Remove the active class from the button after a delay of 500ms
      setTimeout(function () {
        allSimonFlashSignalButtons[buttonNumber].classList.remove("active");
      }, 500);

      // Increment the button index
      buttonIndex++;

      // Check if the button index has exceeded the length of the numbers array
      if (buttonIndex >= simonGenerateRandomArray.length) {
        // Clear the interval, simon has stopped playing, start expiry countdown.
        clearInterval(intervalID);
        isSimonPlaying = false;
        startExpiryCountdown();
      }
    }
  }

  // Call the flashButton() function every 1 second (Default = 1000 milliseconds)
  intervalID = setInterval(flashSimonButtonLight, simonSignalInterval);
}

// Event Listener to handle user clicking of buttons to repeat the simon's signal flashes
allSimonFlashSignalButtons.forEach((button) =>
  button.addEventListener("click", (event) => {
    // Make sure the game is currently being player and simon is not currently playing.
    if (
      isGamePlaying &&
      !isSimonPlaying &&
      simonGenerateRandomArray.length > 0
    ) {
      // Stop expiry countdown to reset it later when user flashes a button for light
      stopExpiryCountdown();
      button.classList.remove("active");
      button.classList.add("active");
      setTimeout(function () {
        button.classList.remove("active");
      }, 500);
      checkUserFlashLightSequence(event);
    }
  })
);

function formatScoreToMin2Digits(number) {
  // Convert the number to a string
  let newNumber = number.toString();

  if (newNumber.length === 1) {
    return `0${newNumber}`;
  } else {
    return newNumber;
  }
}

// Function to check the sequence of button clicks
function checkUserFlashLightSequence(event) {
  // Get the value of the button that was clicked
  let buttonValue = parseInt(event.target.dataset.value);

  // Check if the button value matches the number in the sequence array
  if (
    parseInt(buttonValue) === simonGenerateRandomArray[sequenceIndex]
  ) {

    sequenceIndex++;

  
    startExpiryCountdown();

    // Check if the sequence index has exceeded the length of the numbers array
    if (sequenceIndex >= simonGenerateRandomArray.length) {
      // Stop Timer if it all matches now and comparison is complete
      stopExpiryCountdown();
      currentScore += 1;

      if (currentScore > recordHighScore) {
        recordHighScore = currentScore;
        highScoreNode.innerText = formatScoreToMin2Digits(recordHighScore);
      }

      // Update current score
      currentScoreNode.innerText = formatScoreToMin2Digits(currentScore);

      // Reset the user flash sequence index to 0
      sequenceIndex = 0;

      // Pass the game to simon
      isSimonPlaying = true;
      setTimeout(generateSimonFlashLightsSequence, 1000);
    }
  } else {
    // Stop Timer
    stopExpiryCountdown();

    // Reset the  user flash sequence index to 0
    sequenceIndex = 0;

    // Signal that game is lost and reset gamne.
    signalToUserThatGameHasBeenLost();
    resetGame();
    
  }
}

// Signal to the user that the game has been lost
function signalToUserThatGameHasBeenLost() {
  // Remove all existing flashes
  let count = 0;
  allSimonFlashSignalButtons.forEach(function (button) {
    button.classList.remove("active");
  });

  function flashButtons() {
    allSimonFlashSignalButtons.forEach(function (button) {
      button.classList.add("active");
    });
    setTimeout(function () {
      allSimonFlashSignalButtons.forEach(function (button) {
        button.classList.remove("active");
      });
      count++;
      if (count < 5) {
        setTimeout(flashButtons, 500);
      }
    }, 500);
  }

  flashButtons();
}

// Reset the Game
function resetGame() {
  stopExpiryCountdown();
  isGamePlaying = false;
  isSimonPlaying = false;
  gameStateIndicator.classList.remove("game-on");
  simonGenerateRandomArray = [];
  currentScore = 0;
  sequenceIndex = 0;
  simonGameIteration = 1;
  simonSignalInterval = 1000;
}
